const API_KEY = 'rnd_1Vk5CsbxrWIMnAb4IbO7EJx4ssqR';
const OWNER_ID = 'tea-dbdqnk29lscs73aeprr0';
const repoUrl = 'https://github.com/ascomfredpacheco-wq/rp-resolve';

async function deploy() {
  console.log(`🚀 Conectando ao Render para criar o serviço a partir de: ${repoUrl}`);
  
  const payload = {
    type: 'web_service',
    name: 'rp-resolve',
    ownerId: OWNER_ID,
    repo: repoUrl,
    branch: 'main',
    rootDir: 'rp-resolve-arquivos',
    autoDeployTrigger: 'commit',
    serviceDetails: {
      env: 'node',
      plan: 'free',
      region: 'oregon',
      envSpecificDetails: {
        buildCommand: 'npm install',
        startCommand: 'node src/server.js'
      },
      envVars: [
        { key: 'NODE_VERSION', value: '20.10.0' }
      ]
    }
  };

  const res = await fetch('https://api.render.com/v1/services', {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${API_KEY}`,
      'Accept': 'application/json',
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(payload)
  });

  const data = await res.json();
  if (!res.ok) {
    console.error('Erro na API do Render:', JSON.stringify(data, null, 2));
    process.exit(1);
  }

  console.log('✅ SUCESSO ABSOLUTO! SERVIÇO CRIADO NO RENDER!');
  console.log('ID do Serviço:', data.id);
  console.log('Nome do Serviço:', data.name);
  console.log('URL Permanente:', data.serviceDetails?.url || `https://${data.name}.onrender.com`);

  const fs = await import('node:fs');
  fs.writeFileSync('./data/render-service.json', JSON.stringify(data, null, 2), 'utf-8');
}

deploy();
