# InstaViral Lab Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:executing-plans and superpowers:test-driven-development to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Construir o aplicativo web completo **InstaViral Lab** — um estrategista de crescimento e laboratório de inteligência para Instagram com interface intuitiva estilo chat + painel analítico, comparação direta com o perfil atual do usuário, engenharia reversa de Reels, cruzamento de assuntos em alta do nicho, links de exemplos reais e geração de roteiros/ganchos pontuados de 0 a 100.

**Architecture:** Aplicação full-stack zero-dependency executada via runtime Node.js nativo (`agy-node` v24.21.0), com separação estrita em 4 camadas: (1) `dataCollector.js` para coleta automática pública do Instagram, snapshots verificados de nichos reais e importação; (2) `analyticsEngine.js` para normalização estatística, cálculo de *Outlier Ratio* relativo ao próprio criador, decomposição de engenharia reversa (separando Fato Observado, Inferência e Hipótese) e comparação competitiva com o perfil do usuário; (3) `strategyEngine.js` para cruzamento de assuntos em alta, pontuação 0–100, geração de roteiros/ganchos/carrosséis/stories com links de referência e chat estrategista IA (integrado com IA gratuita Pollinations/Gemini + motor analítico local); (4) Servidor HTTP/API (`server.js`) + Persistência JSON (`storage.js`) + Interface Web Responsiva (`public/`).

**Tech Stack:** Node.js v24.21.0 (`agy-node`), `node:test` + `node:assert/strict` (TDD), `node:http`, `node:fs`, HTML5/CSS3 Moderno (Dark Glassmorphism UI) + Vanilla JS modular.

**Spec:** `C:\Users\Matheus Ferreira\.gemini\antigravity\scratch\insta-viral-lab\docs\superpowers\specs\2026-10-22-insta-viral-lab-design.md`

## Global Constraints

- Operação 100% gratuita e automática ao digitar `@perfil` ou selecionar um nicho.
- Separação explícita entre `[FATO OBSERVADO]`, `[INFERÊNCIA]` e `[HIPÓTESE]` em toda engenharia reversa.
- Proibido inventar métricas privadas (retenção real em segundos, salvamentos privados, alcance único privado) quando não fornecidas; exibir claramente a origem do dado (`sourceType`).
- Cada recomendação e roteiro gerado deve conter links clicáveis de exemplos/referências (`https://www.instagram.com/...`), ganchos alternativos e cruzamento com assuntos em alta do nicho.
- Aprendizado contínuo: resultados reais cadastrados pelo usuário recalibram os pesos do índice estratégico `0–100`.

## Review Focus

- Perfis com zero publicações ou visualizações zeradas não podem gerar divisão por zero (`NaN`/`Infinity`) no cálculo de Outlier Ratio.
- Quando o Instagram bloquear coleta anônima em tempo real (HTTP 401/429/login wall), o coletor deve informar o status real da fonte e carregar dados verificados do nicho ou perfil sem travar a aplicação.
- O cálculo de pontuação `0–100` deve manter limites estritos entre `0` e `100` mesmo após recalibração com resultados reais do usuário.
- Correção manual de classificação (nicho/formato/tema) feita pelo usuário deve persistir e atualizar imediatamente os relatórios.
- Links de exemplos gerados devem ser URLs válidas do Instagram (`https://www.instagram.com/...`).

---

### Task 1: Camada de Coleta, Validação e Persistência (`storage.js` & `dataCollector.js`)

**Files:**
- Create: `src/storage.js`
- Create: `src/dataCollector.js`
- Test: `tests/dataCollector.test.js`

**Interfaces:**
- Produces:
  - `loadDatabase(dbPath)` / `saveDatabase(dbPath, data)`
  - `collectProfileData(handle, options)` -> `{ username, niche, subniches, audience, positioning, sourceType, sourceNotice, followers, posts: [...] }`
  - `getNicheCatalog()` -> lista de 9 nichos pré-mapeados (Humor, Música, Fitness, Gastronomia, Marketing, Turismo, Notícias, Entretenimento, Criadores Brasileiros no Exterior) com assuntos em alta e perfis/Reels de referência com links reais.

- [ ] **Step 1: Write the failing test in `tests/dataCollector.test.js`**
- [ ] **Step 2: Run test with `agy-node --test tests/dataCollector.test.js` to verify RED**
- [ ] **Step 3: Implement `src/storage.js` and `src/dataCollector.js`**
- [ ] **Step 4: Run test with `agy-node --test tests/dataCollector.test.js` to verify GREEN**

---

### Task 2: Motor de Análise de Perfis, Descoberta de Virais Relativos e Engenharia Reversa (`analyticsEngine.js`)

**Files:**
- Create: `src/analyticsEngine.js`
- Test: `tests/analyticsEngine.test.js`

**Interfaces:**
- Consumes: `collectProfileData` output from Task 1
- Produces:
  - `analyzeProfile(profileData)` -> métricas medianas, frequência, formatos, temas, diagnóstico (pontos fortes e oportunidades) e ranking de posts com `outlierMultiplier`
  - `discoverViralOutliers(profilesList)` -> ranking cruzado de Reels com alto desempenho relativo + explicação de por que estudar cada vídeo
  - `reverseEngineerReel(post, profileBaseline)` -> decomposição em `hook`, `development`, `retentionPotential`, `packaging`, `conclusion`, cada item rotulado com `evidenceType: 'FATO OBSERVADO' | 'INFERÊNCIA' | 'HIPÓTESE'`
  - `analyzeNichePatterns(nicheId, profilesList)` -> padrões confirmados em múltiplos perfis, durações, ganchos recorrentes, tendências em alta, temas saturados e oportunidades inexploradas
  - `compareWithUserProfile(userProfile, competitorProfiles)` -> comparação lado a lado, lacunas de formato/tema/frequência e oportunidades imediatas para o perfil do usuário

- [ ] **Step 1: Write the failing test in `tests/analyticsEngine.test.js`**
- [ ] **Step 2: Run test with `agy-node --test tests/analyticsEngine.test.js` to verify RED**
- [ ] **Step 3: Implement `src/analyticsEngine.js`**
- [ ] **Step 4: Run test with `agy-node --test tests/analyticsEngine.test.js` to verify GREEN**

---

### Task 3: Sistema de Pontuação 0–100, Geração de Roteiros/Ganchos e Chat Estrategista IA (`strategyEngine.js`)

**Files:**
- Create: `src/strategyEngine.js`
- Test: `tests/strategyEngine.test.js`

**Interfaces:**
- Consumes: `analyzeProfile`, `analyzeNichePatterns`, `compareWithUserProfile` from Task 2
- Produces:
  - `scoreOpportunity(opportunity, userContext, learnedWeights)` -> `{ totalScore, confidence, breakdown, isInternalIndex: true }`
  - `generateContentPack(params)` -> roteiros completos de Reels (fala, texto na tela, cenas, edição, legenda, CTA), 3 ganchos alternativos A/B/C, carrossel, sequência de Stories, série recorrente, assuntos em alta cruzados e links clicáveis dos exemplos que inspiraram a ideia
  - `updateLearningFromResult(currentWeights, publishedResult)` -> novos pesos calibrados com base no desempenho real do usuário
  - `askStrategistChat(message, appState)` -> resposta inteligente contextualizada (com suporte a LLM gratuito + motor estratégico local)

- [ ] **Step 1: Write the failing test in `tests/strategyEngine.test.js`**
- [ ] **Step 2: Run test with `agy-node --test tests/strategyEngine.test.js` to verify RED**
- [ ] **Step 3: Implement `src/strategyEngine.js`**
- [ ] **Step 4: Run test with `agy-node --test tests/strategyEngine.test.js` to verify GREEN**

---

### Task 4: Servidor API & Interface Web Intuitiva (`server.js` & `public/`)

**Files:**
- Create: `src/server.js`
- Create: `public/index.html`
- Create: `public/styles.css`
- Create: `public/app.js`
- Create: `Iniciar-InstaViral-Lab.bat`
- Test: `tests/server.test.js`

**Interfaces:**
- Consumes: `storage.js`, `dataCollector.js`, `analyticsEngine.js`, `strategyEngine.js`
- Produces:
  - HTTP Server com endpoints REST (`/api/state`, `/api/analyze-profile`, `/api/compare`, `/api/niche-report`, `/api/reverse-engineer`, `/api/generate-content`, `/api/record-result`, `/api/reclassify`, `/api/chat`)
  - Interface web moderna, responsiva e intuitiva em português com Assistente Chat Inteligente + Meu Perfil vs Concorrentes + Descoberta de Virais + Engenharia Reversa + Gerador de Roteiros com Links de Exemplos + Calendário e Aprendizado.

- [ ] **Step 1: Write the failing API integration test in `tests/server.test.js`**
- [ ] **Step 2: Run test with `agy-node --test tests/server.test.js` to verify RED**
- [ ] **Step 3: Implement `src/server.js`, `public/index.html`, `public/styles.css`, `public/app.js`, and `Iniciar-InstaViral-Lab.bat`**
- [ ] **Step 4: Run full test suite `agy-node --test tests/*.test.js` and live server smoke check to verify GREEN**
