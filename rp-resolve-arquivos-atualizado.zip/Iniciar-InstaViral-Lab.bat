@echo off
title RP RESOLVE - Iniciar / Reiniciar Servidor + Link Publico
cd /d "%~dp0"
echo Reiniciando o servidor do RP RESOLVE (porta 3847) e gerando Link Publico...
taskkill /F /IM cloudflared.exe >nul 2>&1
for /f "tokens=5" %%a in ('netstat -aon ^| findstr ":3847" ^| findstr "LISTENING"') do (
    taskkill /F /PID %%a >nul 2>&1
)
timeout /t 1 /nobreak >nul
start "" "http://localhost:3847"
"C:\Users\Matheus Ferreira\AppData\Roaming\Antigravity\bin\agy-node.cmd" src/server.js
pause
