const INSTAGRAM_HOSTS = new Set([
  "instagram.com",
  "www.instagram.com"
]);

export function normalizeUsername(value) {
  if (typeof value !== "string") return null;

  const username = value.trim().replace(/^@/, "");

  // Não aceite URLs, barras ou caracteres de controle como username.
  if (!/^[a-zA-Z0-9._]{1,30}$/.test(username)) {
    return null;
  }

  return username;
}

export function parseInstagramPermalink(value) {
  if (typeof value !== "string" || !value.trim()) {
    return null;
  }

  try {
    const url = new URL(value.trim());

    if (
      url.protocol !== "https:" ||
      !INSTAGRAM_HOSTS.has(url.hostname.toLowerCase()) ||
      url.port ||
      url.username ||
      url.password
    ) {
      return null;
    }

    // Formatos de publicações individuais.
    const match = url.pathname.match(
      /^\/(reel|reels|p|tv)\/([A-Za-z0-9_-]+)\/?$/i
    );

    if (!match) return null;

    const type = match[1].toLowerCase();
    const shortcode = match[2];

    return {
      shortcode,
      mediaType: type === "reels" ? "reel" : type,
      permalink: `https://www.instagram.com/${type}/${shortcode}/`
    };
  } catch {
    return null;
  }
}

/**
 * Normaliza o destino de uma publicação.
 *
 * sourceVerified deve ser true SOMENTE quando a origem confiável
 * confirmou a associação entre a publicação e seus dados.
 *
 * Uma URL sintaticamente válida, sozinha, não prova que o Reel existe.
 */
export function normalizeInstagramLink({
  username,
  permalink,
  shortcode,
  mediaType = "reel",
  sourceVerified = false
}) {
  const safeUsername = normalizeUsername(username);

  if (!safeUsername) {
    throw new Error("Username do Instagram inválido.");
  }

  const profileUrl =
    `https://www.instagram.com/${safeUsername}/`;

  const reelsUrl =
    `https://www.instagram.com/${safeUsername}/reels/`;

  const fallback = {
    shortcode: null,
    permalink: null,
    profileUrl,
    reelsUrl,
    url: reelsUrl,
    linkType: "profile_fallback",
    linkVerified: false,
    verificationStatus: "unverified"
  };

  // O permalink de uma fonte confiável tem prioridade.
  const parsedUrl = parseInstagramPermalink(permalink);

  if (parsedUrl) {
    // Se a fonte também forneceu shortcode, os dois devem coincidir.
    if (
      shortcode &&
      shortcode !== parsedUrl.shortcode
    ) {
      return {
        ...fallback,
        verificationStatus: "invalid"
      };
    }

    // Só marcamos como verificado se a origem confirmou os dados.
    if (!sourceVerified) {
      return {
        ...fallback,
        shortcode: parsedUrl.shortcode,
        verificationStatus: "unverified"
      };
    }

    return {
      shortcode: parsedUrl.shortcode,
      permalink: parsedUrl.permalink,
      profileUrl,
      reelsUrl,
      url: parsedUrl.permalink,
      linkType: parsedUrl.mediaType === "reel"
        ? "reel"
        : "post",
      linkVerified: true,
      verificationStatus: "valid"
    };
  }

  // Um shortcode isolado só é aceito com origem confiável.
  if (
    sourceVerified &&
    typeof shortcode === "string" &&
    /^[A-Za-z0-9_-]+$/.test(shortcode) &&
    ["reel", "p", "tv"].includes(mediaType)
  ) {
    const canonicalUrl =
      `https://www.instagram.com/${mediaType}/${shortcode}/`;

    return {
      shortcode,
      permalink: canonicalUrl,
      profileUrl,
      reelsUrl,
      url: canonicalUrl,
      linkType: mediaType === "reel" ? "reel" : "post",
      linkVerified: true,
      verificationStatus: "valid"
    };
  }

  // Nunca invente um identificador de publicação.
  return fallback;
}

export default {
  normalizeUsername,
  parseInstagramPermalink,
  normalizeInstagramLink
};
