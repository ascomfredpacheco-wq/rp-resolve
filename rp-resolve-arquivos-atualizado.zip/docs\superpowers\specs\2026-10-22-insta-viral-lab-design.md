# Design & Arquitetura: InstaViral Lab (Laboratório de Inteligência de Conteúdo para Instagram)

**Data:** 2026-10-22  
**Status:** Aguardando aprovação final do usuário

---

## 1. Intenção e Objetivo (O "Porquê")
Construir uma aplicação web completa, 100% gratuita e automatizada que funciona como um **Estrategista de Crescimento e Laboratório de Inteligência de Conteúdo para Instagram**.
O usuário apenas digita o `@perfil` (ou seleciona um nicho com múltiplos `@perfis`) e clica em **Analisar**. O sistema coleta os dados públicos disponíveis, calcula o desempenho relativo (outliers), faz engenharia reversa de Reels virais separando **Fatos Observados** de **Hipóteses**, pontua oportunidades de `0 a 100` e gera roteiros originais adaptados ao perfil do usuário.

---

## 2. Metas, Não-Metas e Anti-Metas
* **Metas:**
  * Operação 100% gratuita e automática a partir do `@perfil` ou seleção de nicho.
  * Descoberta de viralização relativa (*Viral Outlier Index* = desempenho da publicação comparado à mediana/média histórica do próprio criador).
  * Separação explícita entre **Fato Observado** (métrica pública visível, texto da legenda, duração, data), **Inferência** (padrão estatístico repetido no perfil/nicho) e **Hipótese** (possível mecanismo psicológico de retenção).
  * Geração de conteúdos originais (roteiros de Reels, ganchos A/B, carrosséis, stories, calendário editorial) fundamentados nos padrões reais encontrados.
  * Aprendizado contínuo com feedback/resultados reais das publicações do usuário e correção manual de classificações.
* **Não-Metas:**
  * Automatizar postagens ou interações (curtir/comentar) em nome do usuário.
* **Anti-Metas (O que tornaria o projeto uma falha mesmo funcionando tecnicamente):**
  * Inventar métricas privadas (como retenção real em segundos, alcance único privado ou salvamentos privados quando não fornecidos) e apresentá-las como fatos.
  * Simular dados fictícios dizendo que vieram do Instagram sem avisar claramente a origem do dado.
  * Gerar conselhos genéricos ("poste todo dia às 18h") sem apontar quais publicações fundamentam a recomendação.

---

## 3. Abordagens Consideradas e Escolha
1. **Opção 1 (Escolhida): Web App Local Completo (Node.js + SQLite/JSON DB + Coletor Automático Multi-Camada + Motor de IA Híbrido Gratuito)**
   * *Vantagem:* Custo zero, 100% automático ao digitar o `@`, banco de dados persistente na máquina do usuário, separação limpa entre camada de coleta e camada de IA.
2. **Opção 2: Painel 100% Manual Offline** — Descartada por exigir trabalho manual constante do usuário.
3. **Opção 3: Extensão de Navegador Embutida** — Descartada por limitar o dashboard comparativo de múltiplos perfis e planejamento editorial.

---

## 4. Arquitetura Técnica e Fluxo de Dados (10 Etapas)

```text
[Usuário digita @perfil ou escolhe Nicho]
       │
       ▼
[Camada 1: Coleta & Validação (Data Adapters)]
  ├── Conector Automático Público (Web / GraphQL Público / Scraper Headless Local)
  ├── Conector API Oficial / Provedor Externo (Opcional: Meta Graph API / Apify Free)
  └── Conector de Importação/Correção (JSON/CSV/Links + Base de Perfis Reais Auditados por Nicho)
       │ (Registra origem exata de cada dado: "web_public", "api", "imported", "verified_snapshot")
       ▼
[Camada 2: Normalização & Cálculo Estatístico]
  ├── Cálculo de Mediana/Média do Perfil (Views, Likes, Comentários, Engajamento Público)
  ├── Cálculo do Índice de Viralização Relativa (Outlier Ratio = Views do Reel / Mediana do Perfil)
  └── Ajuste por Idade da Publicação (Velocidade de tração observável)
       │
       ▼
[Camada 3: Motor de Inteligência Artificial (10 Etapas)]
  ├── Classificação de Nicho, Subnicho, Formato (Reel, Carrossel, Estático) e Tema
  ├── Engenharia Reversa de Reels (Gancho, Desenvolvimento, Retenção Potencial, Embalagem, Conclusão)
  ├── Detecção de Padrões Cruzados do Nicho (confirmados em múltiplos criadores)
  ├── Inteligência Competitiva (Comparação lado a lado + Lacunas de conteúdo)
  ├── Sistema de Pontuação 0–100 (Índice Estratégico Interno + Grau de Confiança)
  └── Gerador de Conteúdo Original (Roteiros completos, Ganchos A/B, Carrosséis, Stories, Séries)
       │
       ▼
[Camada 4: Persistência & Aprendizado Contínuo (Banco Local)]
  └── Histórico de Perfis, Biblioteca de Conteúdos, Calendário Editorial, Resultados Reais do Usuário (Recalibra pesos do Score 0–100)
```

---

## 5. Módulos do Produto
1. **Dashboard Principal:** Visão executiva com KPIs de desempenho relativo, top outliers, padrões virais, ranking de oportunidades e acesso rápido às evidências.
2. **Módulo de Análise de Perfis (`@username`):** Diagnóstico completo do perfil (nicho, público provável, proposta de valor, frequência, formatos, outliers, padrões de ganchos/CTAs e evolução). Permite editar/corrigir classificações da IA.
3. **Módulo de Descoberta de Conteúdos Virais (Outliers):** Ranking ordenado por **Multiplicador de Desempenho Relativo** (ex.: Reel com `12,4x` a média do próprio perfil), explicando por que merece estudo.
4. **Módulo de Engenharia Reversa de Reels:** Decomposição estruturada em 5 blocos (*Gancho Inicial, Desenvolvimento, Retenção Potencial, Embalagem, Conclusão*), com etiquetas visuais claras separando **[FATO OBSERVADO]**, **[INFERÊNCIA]** e **[HIPÓTESE]**.
5. **Módulo de Padrões do Nicho:** Análise simultânea de múltiplos perfis de um nicho (Humor, Música, Fitness, Gastronomia, Marketing, Turismo, Notícias, Entretenimento, Brasileiros no Exterior), destacando padrões confirmados em mais de um criador, temas saturados e oportunidades inexploradas.
6. **Módulo de Inteligência Competitiva:** Comparação lado a lado entre o perfil do usuário e concorrentes/referências, apontando diferenciais e lacunas (*content gaps*).
7. **Sistema de Pontuação e Priorização (0–100):** Avalia oportunidades em 9 critérios (Força do gancho, Adequação ao público, Evidência do formato, Originalidade, Potencial de compartilhamento, Clareza da promessa, Facilidade de produção, Saturação do tema, Compatibilidade com o perfil) + Nível de Confiança.
8. **Módulo de Geração de Conteúdo + Calendário Editorial:** Gera roteiros completos de Reels (fala + texto em tela + cenas + edição + legenda + CTA), variações de ganchos A/B, carrosséis, sequência de Stories e séries recorrentes, sempre citando qual padrão real inspirou a ideia.
9. **Monitoramento de Resultados e Aprendizado:** O usuário registra o resultado real dos conteúdos que publicou; o sistema recalibra os pesos dos formatos/ganchos que melhor funcionam para ele.

---

## 6. Riscos Técnicos e Mitigações (Transparência)
* **Limitação de Acesso Público do Instagram (Rate-limit / Login Wall):** O Instagram frequentemente bloqueia requisições anônimas repetidas.
  * *Solução Técnica:* A camada de coleta (`DataCollectorService`) tenta primeiro a extração pública automática em tempo real; se o Instagram bloquear o IP temporariamente, o sistema informa com transparência a origem do bloqueio, permite conectar chave gratuita (Apify/Meta) ou usar snapshots reais verificados / importação rápida, sempre exibindo um selo claro da **Fonte dos Dados** em cada análise.
* **Custo de IA:** Para manter custo zero sem exigir cartão de crédito, o aplicativo combina um **Motor Analítico NLP/Estatístico Local** com suporte direto a **IA Gratuita (Pollinations AI sem chave / Google Gemini Free API Key opcional)**.
