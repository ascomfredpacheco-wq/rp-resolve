import test from 'node:test';
import assert from 'node:assert/strict';
import {
  normalizeUsername,
  parseInstagramPermalink,
  normalizeInstagramLink
} from '../src/instagramLinkResolver.js';

test('normalizeUsername limpa @ e valida formato seguro', () => {
  assert.equal(normalizeUsername('@doutorfran'), 'doutorfran');
  assert.equal(normalizeUsername('  anaelisast  '), 'anaelisast');
  assert.equal(normalizeUsername('usuario.valido_123'), 'usuario.valido_123');
  assert.equal(normalizeUsername('http://invalido.com'), null);
  assert.equal(normalizeUsername('@usuario/com/barra'), null);
  assert.equal(normalizeUsername(null), null);
});

test('parseInstagramPermalink extrai shortcode e mediaType de URLs reais do Instagram', () => {
  const reelParsed = parseInstagramPermalink('https://www.instagram.com/reel/De1fO-zMoF-/');
  assert.equal(reelParsed?.shortcode, 'De1fO-zMoF-');
  assert.equal(reelParsed?.mediaType, 'reel');
  assert.equal(reelParsed?.permalink, 'https://www.instagram.com/reel/De1fO-zMoF-/');

  const pParsed = parseInstagramPermalink('https://instagram.com/p/C9xY8z1Ab2c');
  assert.equal(pParsed?.shortcode, 'C9xY8z1Ab2c');
  assert.equal(pParsed?.mediaType, 'p');

  assert.equal(parseInstagramPermalink('https://outro-site.com/reel/123/'), null);
  assert.equal(parseInstagramPermalink('https://instagram.com/noticias/'), null);
});

test('normalizeInstagramLink protege contra 404 e nunca inventa links fictícios', () => {
  // Caso 1: Fonte não verificada (deve redirecionar para reelsUrl canônica e shortcode null)
  const unverified = normalizeInstagramLink({
    username: 'doutorfran',
    permalink: 'https://www.instagram.com/reel/doutorfran-reel-1/',
    sourceVerified: false
  });
  assert.equal(unverified.linkVerified, false);
  assert.equal(unverified.url, 'https://www.instagram.com/doutorfran/reels/');

  // Caso 2: Reel verificado por fonte confiável
  const verified = normalizeInstagramLink({
    username: 'anaelisast',
    permalink: 'https://www.instagram.com/reel/De1fO-zMoF-/',
    sourceVerified: true
  });
  assert.equal(verified.linkVerified, true);
  assert.equal(verified.shortcode, 'De1fO-zMoF-');
  assert.equal(verified.url, 'https://www.instagram.com/reel/De1fO-zMoF-/');

  // Caso 3: Sem link específico fornecido -> fallback seguro para reels
  const empty = normalizeInstagramLink({
    username: 'fredpacheco',
    sourceVerified: false
  });
  assert.equal(empty.linkVerified, false);
  assert.equal(empty.url, 'https://www.instagram.com/fredpacheco/reels/');
});
