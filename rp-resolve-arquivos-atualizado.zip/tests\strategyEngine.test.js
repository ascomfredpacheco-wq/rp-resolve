import test from 'node:test';
import assert from 'node:assert/strict';
import {
  scoreOpportunity,
  generateContentPack,
  updateLearningFromResult,
  askStrategistChat,
  buildValidSeed,
  buildOpenChatMessages,
  getAIEnginesCatalog,
  detectQueryIntent
} from '../src/strategyEngine.js';
import { buildVisualAnalytics } from '../src/visualAnalytics.js';
import { collectProfileData } from '../src/dataCollector.js';
import { analyzeProfile } from '../src/analyticsEngine.js';

test('scoreOpportunity calcula nota de 0 a 100 com 9 critérios, evidências e índice interno', () => {
  const score = scoreOpportunity({
    hookStrength: 92,
    audienceFit: 88,
    formatEvidence: 95,
    originality: 84,
    shareability: 90,
    promiseClarity: 89,
    productionEase: 80,
    lowSaturation: 86,
    positioningFit: 91,
    referenceMultiplier: 9.4
  });

  assert.equal(score.totalScore >= 0 && score.totalScore <= 100, true);
  assert.equal(score.isInternalStrategicIndex, true);
  assert.equal(score.criteriaBreakdown.length, 9);
  assert.ok(score.confidenceLevel);
  assert.ok(score.disclaimer.includes('índice estratégico interno'));
});

test('generateContentPack cria roteiros de Reels, ganchos A/B/C, carrossel, stories e links de referência', async () => {
  const userProf = analyzeProfile(await collectProfileData('@meu_perfil', { nicheHint: 'marketing', isUserOwnProfile: true, skipNetwork: true }));
  const compProf = analyzeProfile(await collectProfileData('@referencia_top', { nicheHint: 'marketing', skipNetwork: true }));

  const pack = generateContentPack({
    userProfile: userProf,
    competitors: [compProf],
    nicheId: 'marketing',
    goal: 'Crescer seguidores qualificados e vender no Direct',
    style: 'Direto, prático e conversacional',
    resources: 'Celular + iluminação natural'
  });

  assert.ok(pack.prioritizedIdeas.length >= 3);
  const first = pack.prioritizedIdeas[0];
  assert.ok(first.score.totalScore >= 60 && first.score.totalScore <= 100);
  assert.equal(first.alternativeHooks.length, 3);
  assert.ok(first.reelScript.spokenText);
  assert.ok(first.reelScript.onScreenText);
  assert.ok(first.reelScript.scenesAndFraming);
  assert.ok(first.reelScript.editingNotes);
  assert.ok(first.reelScript.caption);
  assert.ok(first.reelScript.cta);
  assert.ok(first.inspiredByPattern);
  assert.equal(Array.isArray(first.referenceLinks), true);
  assert.match(first.referenceLinks[0].url, /^https:\/\/www\.instagram\.com\//);
  assert.ok(pack.carouselPlan.slides.length >= 5);
  assert.ok(pack.storiesSequence.length >= 4);
  assert.ok(pack.recurringSeries.title);
});

test('updateLearningFromResult recalibra pesos com base no desempenho real do usuário', () => {
  const initialWeights = {
    hookStrength: 1.0,
    preferredFormats: {},
    preferredHookTypes: {}
  };

  const updated = updateLearningFromResult(initialWeights, {
    format: 'Reel',
    hookType: 'Quebra de Expectativa + Erro Comum',
    views: 25000,
    userBaselineViews: 2500
  });

  assert.ok(updated.preferredFormats['Reel'] > 1.0);
  assert.ok(updated.preferredHookTypes['Quebra de Expectativa + Erro Comum'] > 1.0);
});

test('askStrategistChat responde de forma única e específica para cada pergunta diferente do usuário (nunca repete a mesma resposta)', async () => {
  const userProf = analyzeProfile(await collectProfileData('@fredpachecorj', { nicheHint: 'politica', isUserOwnProfile: true, skipNetwork: true }));
  const compProf = analyzeProfile(await collectProfileData('@nikolasferreiradm', { nicheHint: 'politica', skipNetwork: true }));
  const state = {
    userProfile: userProf,
    competitors: [compProf],
    selectedNiche: 'politica'
  };

  const replyBio = await askStrategistChat(
    'Crie 3 opções de bio para o meu perfil político',
    state,
    { skipExternalLLM: true }
  );

  const replyHospital = await askStrategistChat(
    'Crie um roteiro de fiscalização sobre filas em hospitais no Rio de Janeiro',
    state,
    { skipExternalLLM: true }
  );

  assert.notEqual(replyBio.text, replyHospital.text);
  assert.match(replyBio.text, /bio/i);
  assert.match(replyHospital.text, /hospitais/i);
});

test('buildValidSeed gera seed 32-bit válido (<= 2147483647) e buildOpenChatMessages inclui histórico multi-turno e dados profundos dos perfis', async () => {
  const seed = buildValidSeed();
  assert.equal(typeof seed, 'number');
  assert.ok(seed >= 1 && seed <= 2147483647);

  const userProf = analyzeProfile(await collectProfileData('@fredpachecorj', { nicheHint: 'politica', isUserOwnProfile: true, skipNetwork: true }));
  const compProf = analyzeProfile(await collectProfileData('@nikolasferreiradm', { nicheHint: 'politica', skipNetwork: true }));
  const state = {
    userProfile: userProf,
    competitors: [compProf],
    selectedNiche: 'politica',
    chatHistory: [
      { role: 'user', text: 'Desmonte o Reel campeão' },
      { role: 'assistant', text: 'Aqui está a análise inicial do Reel.' }
    ]
  };

  const messages = buildOpenChatMessages('E como eu adapto o gancho desse vídeo para falar de segurança pública?', state);
  assert.ok(Array.isArray(messages));
  assert.equal(messages[0].role, 'system');
  assert.ok(messages[0].content.includes('fredpachecorj'));
  assert.ok(messages[0].content.includes('nikolasferreiradm'));
  assert.ok(messages.some((m) => m.role === 'user' && m.content.includes('Desmonte o Reel campeão')));
  assert.equal(messages[messages.length - 1].content, 'E como eu adapto o gancho desse vídeo para falar de segurança pública?');

  // Também garante que mesmo em modo offline duas perguntas sobre engenharia reversa geram respostas diferentes e abertas
  const r1 = await askStrategistChat('Desmonte o Reel campeão dos perfis listados passo a passo', state, { skipExternalLLM: true });
  const r2 = await askStrategistChat('Por que a engenharia reversa desse Reel campeão teve tantos comentários polêmicos?', state, { skipExternalLLM: true });
  assert.notEqual(r1.text, r2.text);
});

test('getAIEnginesCatalog lista ChatGPT, Claude, Gemini, DeepSeek, Llama e Fusão Multi-IA, e askStrategistChat adapta o motor escolhido', async () => {
  const engines = getAIEnginesCatalog();
  assert.ok(Array.isArray(engines) && engines.length >= 6);
  const ids = engines.map((e) => e.id);
  assert.ok(ids.includes('fusion'));
  assert.ok(ids.includes('chatgpt'));
  assert.ok(ids.includes('claude'));
  assert.ok(ids.includes('gemini'));
  assert.ok(ids.includes('deepseek'));
  assert.ok(ids.includes('llama'));

  const userProf = analyzeProfile(await collectProfileData('@fredpachecorj', { nicheHint: 'politica', isUserOwnProfile: true, skipNetwork: true }));
  const compProf = analyzeProfile(await collectProfileData('@nikolasferreiradm', { nicheHint: 'politica', skipNetwork: true }));
  const state = {
    userProfile: userProf,
    competitors: [compProf],
    selectedNiche: 'politica'
  };

  const resGpt = await askStrategistChat('Me dê um gancho forte sobre impostos', { ...state, selectedAIEngine: 'chatgpt' }, { skipExternalLLM: true });
  const resClaude = await askStrategistChat('Me dê um gancho forte sobre impostos', { ...state, selectedAIEngine: 'claude' }, { skipExternalLLM: true });
  const resFusion = await askStrategistChat('Me dê um gancho forte sobre impostos', { ...state, selectedAIEngine: 'fusion' }, { skipExternalLLM: true });

  assert.match(resGpt.model, /ChatGPT/i);
  assert.match(resClaude.model, /Claude/i);
  assert.match(resFusion.model, /Fusão Multi-IA/i);
  assert.notEqual(resGpt.text, resClaude.text);
  assert.ok(resFusion.text.includes('ChatGPT') && resFusion.text.includes('Claude') && resFusion.text.includes('Gemini'));
});

test('generateContentPack inclui veredito do Conselho Multi-IA (ChatGPT, Claude, Gemini, DeepSeek, Llama) e referência Swipe-to-Script em cada roteiro', async () => {
  const userProf = analyzeProfile(await collectProfileData('@fredpachecorj', { nicheHint: 'politica', isUserOwnProfile: true, skipNetwork: true }));
  const compProf = analyzeProfile(await collectProfileData('@nikolasferreiradm', { nicheHint: 'politica', skipNetwork: true }));

  const pack = generateContentPack({
    userProfile: userProf,
    competitors: [compProf],
    nicheId: 'politica',
    customTopic: 'Fiscalização de obras paradas'
  });

  const first = pack.prioritizedIdeas[0];
  assert.ok(first.multiAiCouncil);
  assert.ok(first.multiAiCouncil.chatgpt.length > 10);
  assert.ok(first.multiAiCouncil.claude.length > 10);
  assert.ok(first.multiAiCouncil.gemini.length > 10);
  assert.ok(first.multiAiCouncil.deepseek.length > 10);
  assert.ok(first.multiAiCouncil.llama.length > 10);
  assert.ok(first.consensusAgreement);
  assert.ok(first.consensusAgreement.unifiedVerdict.length > 20);
  assert.equal(Array.isArray(first.consensusAgreement.agreedPillars), true);
  assert.ok(first.storyboardSvg.startsWith('data:image/svg+xml'));
  assert.ok(first.aiCoverUrl.startsWith('https://image.pollinations.ai/'));
  assert.ok(first.referenceVideoSnapshot);
  assert.ok(first.referenceVideoSnapshot.videoUrl.startsWith('https://www.instagram.com/'));
});

test('IA Universal responde sobre qualquer assunto do mundo (matemática, código, vendas/Salesforce, finanças) e sobre o próprio app em acordo único', async () => {
  assert.equal(detectQueryIntent('Como funciona a arquitetura do app RP RESOLVE?'), 'app_help');
  assert.equal(detectQueryIntent('Crie 3 opções de bio para o meu Instagram'), 'instagram_strategy');
  assert.equal(detectQueryIntent('Como estruturar um funil de vendas no padrão Salesforce CRM?'), 'world_knowledge');

  const mathReply = await askStrategistChat('Quanto é 150 * 12?', {}, { skipExternalLLM: true });
  assert.match(mathReply.text, /1\.800|1800/);

  const appReply = await askStrategistChat('Como funciona a arquitetura do app RP RESOLVE?', {}, { skipExternalLLM: true });
  assert.match(appReply.text, /Salesforce Lightning/i);
  assert.ok(appReply.visualAttachment?.storyboardSvg);

  const salesforceReply = await askStrategistChat('Como estruturar um funil de vendas no padrão Salesforce?', {}, { skipExternalLLM: true });
  assert.match(salesforceReply.text, /Pipeline|BANT|Customer 360/i);

  const codeReply = await askStrategistChat('Me mostre um exemplo de código em JavaScript modular', {}, { skipExternalLLM: true });
  assert.match(codeReply.text, /function executarProcesso/);
});

test('buildVisualAnalytics gera dados estruturados para gráficos comparativos, curva de retenção e storyboards', async () => {
  const userProf = analyzeProfile(await collectProfileData('@meu_perfil', { nicheHint: 'marketing', isUserOwnProfile: true, skipNetwork: true }));
  const compProf = analyzeProfile(await collectProfileData('@referencia_top', { nicheHint: 'marketing', skipNetwork: true }));
  const pack = generateContentPack({ userProfile: userProf, competitors: [compProf], nicheId: 'marketing' });

  const va = buildVisualAnalytics({
    userProfile: userProf,
    competitors: [compProf],
    viralOutliers: compProf.outliers,
    contentPack: pack,
    nicheReport: { nicheName: 'Marketing Digital', trendingTopics: [{ topic: 'IA', growthVelocity: '+240%' }] }
  });

  assert.equal(va.competitorComparisonChart.length, 2);
  assert.equal(va.retentionCurveChart.points.length, 7);
  assert.equal(va.formatPerformanceChart.length, 3);
  assert.ok(va.extremeVideoStoryboard.startsWith('data:image/svg+xml'));
});

