let currentState = null;
let listedCompetitors = [];
let activePlayingReel = null;

function esc(str) {
  return String(str ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function cleanHandle(raw) {
  if (!raw) return '';
  return raw
    .trim()
    .replace(/^https?:\/\/(www\.)?instagram\.com\//i, '')
    .split('/')[0]
    .split('?')[0]
    .replace(/^@+/, '')
    .trim()
    .toLowerCase();
}

function makeInlineAvatarSvg(handle, bg = '#0284c7') {
  const clean = String(handle || 'u').replace(/^@/, '').trim() || 'u';
  const initials = clean.slice(0, 2).toUpperCase();
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="36" height="36" viewBox="0 0 36 36"><rect width="36" height="36" rx="9" fill="${bg}"/><text x="18" y="23" font-family="sans-serif" font-size="13" font-weight="800" fill="#fff" text-anchor="middle">${initials}</text></svg>`;
  return `data:image/svg+xml;utf8,${encodeURIComponent(svg)}`;
}

function renderListedChips() {
  const box = document.getElementById('listedProfilesChips');
  if (!box) return;

  if (listedCompetitors.length === 0) {
    box.innerHTML = `<span style="color:var(--text-muted); font-size:0.75rem;">Nenhum concorrente listado. Digite acima e clique em "+ Add".</span>`;
    return;
  }

  const colors = ['#0284c7', '#10b981', '#f59e0b', '#8b5cf6'];
  box.innerHTML = listedCompetitors
    .map(
      (handle, idx) => `
      <span class="profile-chip">
        <img src="${makeInlineAvatarSvg(handle, colors[idx % colors.length])}" alt="@${esc(handle)}" />
        @${esc(handle)}
        <button type="button" data-remove-idx="${idx}" title="Remover @${esc(handle)}">✕</button>
      </span>`
    )
    .join('');

  box.querySelectorAll('button[data-remove-idx]').forEach((btn) => {
    btn.addEventListener('click', () => {
      const i = Number(btn.getAttribute('data-remove-idx'));
      listedCompetitors.splice(i, 1);
      renderListedChips();
    });
  });
}

function addHandleFromInput() {
  const input = document.getElementById('addCompetitorInput');
  if (!input) return;
  const parts = input.value
    .split(',')
    .map(cleanHandle)
    .filter(Boolean);

  for (const p of parts) {
    if (!listedCompetitors.includes(p)) {
      listedCompetitors.push(p);
    }
  }
  input.value = '';
  renderListedChips();
}

const TEAM_HEADERS = { 'x-team-workspace': 'ascom' };

async function fetchState() {
  try {
    const res = await fetch('/api/state', { headers: { ...TEAM_HEADERS } });
    currentState = await res.json();
    listedCompetitors = Array.isArray(currentState.competitors)
      ? currentState.competitors.map((c) => c.username)
      : [];
    renderAll();
  } catch (err) {
    console.error('Erro ao carregar estado:', err);
  }
}

async function triggerLiveSync() {
  const syncBtn = document.getElementById('liveSyncBtn');
  const oldText = syncBtn ? syncBtn.textContent : '';
  if (syncBtn) {
    syncBtn.textContent = '⏳ Sincronizando...';
    syncBtn.disabled = true;
  }

  try {
    const res = await fetch('/api/live-sync', { method: 'POST', headers: { ...TEAM_HEADERS } });
    const data = await res.json();
    if (data.dashboard) {
      currentState = data.dashboard;
      const label = document.getElementById('lastSyncLabel');
      if (label) {
        label.textContent = `🟢 Sincronizado às ${new Date().toLocaleTimeString('pt-BR')}`;
      }
      renderAll();
    }
  } catch (err) {
    console.error('Erro no live sync:', err);
  } finally {
    if (syncBtn) {
      syncBtn.textContent = oldText;
      syncBtn.disabled = false;
    }
  }
}

function renderAll() {
  if (!currentState) return;

  const nicheSelect = document.getElementById('nicheSelect');
  if (nicheSelect && Array.isArray(currentState.niches)) {
    nicheSelect.innerHTML = currentState.niches
      .map((n) => `<option value="${esc(n.id)}">${esc(n.name)}</option>`)
      .join('');
    nicheSelect.value = currentState.selectedNiche || 'marketing';
  }

  const userHandleInput = document.getElementById('userHandleInput');
  if (userHandleInput) {
    userHandleInput.value = currentState.userProfile?.username ? `@${currentState.userProfile.username}` : '';
  }

  renderListedChips();
  renderKpis();
  renderTrendingReelsGrid();
  renderLiveProfilesTable();
  renderScriptsTab();
  renderChatMessages();
}

function showToast(message) {
  let toast = document.getElementById('toastNotification');
  if (!toast) return;
  toast.textContent = message;
  toast.classList.remove('hidden');
  toast.style.opacity = '1';
  setTimeout(() => {
    toast.style.opacity = '0';
    setTimeout(() => { toast.classList.add('hidden'); }, 300);
  }, 2600);
}

function renderKpis() {
  const box = document.getElementById('summaryStrip');
  if (!box || !currentState) return;

  const user = currentState.userProfile;
  const topOutlier = currentState.viralOutliers?.[0] || {};
  const compCount = (currentState.competitors || []).length;
  const medianViews = user?.baselineMedianViews || 1200;
  const selectedNiche = currentState.niches?.find((n) => n.id === currentState.selectedNiche);
  const nicheName = selectedNiche?.name || 'Geral';
  const outlierMult = topOutlier.outlierMultiplier ? `${topOutlier.outlierMultiplier}x` : '9.8x';

  box.innerHTML = `
    <div class="kpi-card-bento">
      <div class="kpi-gauge-wrap">
        <svg viewBox="0 0 36 36">
          <path class="kpi-gauge-bg" d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"/>
          <path class="kpi-gauge-bar" stroke="var(--brand)" stroke-dasharray="88, 100" d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"/>
        </svg>
        <span class="kpi-gauge-val">88%</span>
      </div>
      <div class="kpi-meta">
        <h4>Potencial Viral</h4>
        <div class="kpi-num">${esc(outlierMult)}</div>
        <div class="kpi-sub">Pico sobre a média do nicho</div>
      </div>
    </div>

    <div class="kpi-card-bento">
      <div class="kpi-gauge-wrap">
        <svg viewBox="0 0 36 36">
          <path class="kpi-gauge-bg" d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"/>
          <path class="kpi-gauge-bar" stroke="var(--emerald)" stroke-dasharray="92, 100" d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"/>
        </svg>
        <span class="kpi-gauge-val">92%</span>
      </div>
      <div class="kpi-meta">
        <h4>Retenção Inicial (0-3s)</h4>
        <div class="kpi-num">3.2x</div>
        <div class="kpi-sub">Eficácia dos ganchos diretos</div>
      </div>
    </div>

    <div class="kpi-card-bento">
      <div class="kpi-gauge-wrap">
        <svg viewBox="0 0 36 36">
          <path class="kpi-gauge-bg" d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"/>
          <path class="kpi-gauge-bar" stroke="var(--cyan)" stroke-dasharray="75, 100" d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"/>
        </svg>
        <span class="kpi-gauge-val">${compCount}</span>
      </div>
      <div class="kpi-meta">
        <h4>Perfis Mapeados</h4>
        <div class="kpi-num">${compCount} líderes</div>
        <div class="kpi-sub">Eixo: ${esc(nicheName.split(',')[0])}</div>
      </div>
    </div>

    <div class="kpi-card-bento">
      <div class="kpi-gauge-wrap">
        <svg viewBox="0 0 36 36">
          <path class="kpi-gauge-bg" d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"/>
          <path class="kpi-gauge-bar" stroke="var(--amber)" stroke-dasharray="80, 100" d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"/>
        </svg>
        <span class="kpi-gauge-val">👁️</span>
      </div>
      <div class="kpi-meta">
        <h4>Base Habitual</h4>
        <div class="kpi-num">${Number(medianViews).toLocaleString('pt-BR')}</div>
        <div class="kpi-sub">Mediana de visualizações</div>
      </div>
    </div>
  `;
}

function renderTrendingReelsGrid() {
  const grid = document.getElementById('trendingReelsGrid');
  if (!grid || !currentState) return;

  const outliers = currentState.viralOutliers || [];
  if (outliers.length === 0) {
    grid.innerHTML = `<p style="grid-column:1/-1; color:var(--text-muted); font-size:0.82rem; padding:1rem;">Nenhum Reel em alta identificado ainda. Adicione perfis concorrentes acima e clique em Atualizar Radar.</p>`;
    return;
  }

  grid.innerHTML = outliers.slice(0, 8).map((reel, idx) => {
    const author = reel.username || 'referencia';
    const hasValidSc = Boolean(reel.linkVerified && reel.shortcode);
    const directPostUrl = hasValidSc
      ? `https://www.instagram.com/reel/${reel.shortcode}/`
      : (reel.videoUrl || reel.reelsUrl || `https://www.instagram.com/${author}/reels/`);

    return `
      <div class="reel-card-bento" data-reel-idx="${idx}">
        <div class="reel-card-top">
          <div class="reel-user-tag">
            <img class="reel-user-avatar" src="${makeInlineAvatarSvg(reel.username)}" alt="@${esc(reel.username)}" />
            <span>@${esc(reel.username)}</span>
          </div>
          <span class="reel-mult-tag">🔥 ${esc(reel.outlierMultiplier)}x</span>
        </div>

        <p class="reel-hook-quote">"${esc(reel.hookText || reel.theme || 'Abertura direta na prova visual')}"</p>

        <div class="reel-meta-row">
          <span>${Number(reel.views || 0).toLocaleString('pt-BR')} views</span>
          <button type="button" class="btn-open-reel-mini" data-mini-open-idx="${idx}">
            ▶️ Ver na Mini Janela
          </button>
        </div>
      </div>
    `;
  }).join('');

  grid.querySelectorAll('button[data-mini-open-idx]').forEach((btn) => {
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      const idx = Number(btn.getAttribute('data-mini-open-idx'));
      const reel = outliers[idx];
      if (reel) openMiniReelPlayer(reel);
    });
  });

  grid.querySelectorAll('.reel-card-bento').forEach((card) => {
    card.addEventListener('click', () => {
      const idx = Number(card.getAttribute('data-reel-idx'));
      const reel = outliers[idx];
      if (reel) openMiniReelPlayer(reel);
    });
  });
}

function openMiniReelPlayer(reel) {
  activePlayingReel = reel;
  const modal = document.getElementById('miniPlayerModal');
  if (!modal) return;

  const handleEl = document.getElementById('miniPlayerHandle');
  const badgeEl = document.getElementById('miniPlayerBadge');
  const viewsEl = document.getElementById('miniPlayerViews');
  const durEl = document.getElementById('miniPlayerDuration');
  const tagEl = document.getElementById('miniPlayerTag');
  const hookEl = document.getElementById('miniPlayerHook');
  const extLink = document.getElementById('miniPlayerExternalLink');
  const urlDisplay = document.getElementById('miniPlayerUrlDisplay');
  const centerPlayLink = document.getElementById('miniPlayerCenterPlayLink');
  const iframe = document.getElementById('miniPlayerIframe');
  const mockup = document.getElementById('miniPlayerMockup');

  const username = reel.username || 'perfil';
  const hasSpecificSc = Boolean(reel.linkVerified && reel.shortcode);
  const directPostUrl = hasSpecificSc
    ? `https://www.instagram.com/reel/${reel.shortcode}/`
    : (reel.videoUrl || reel.reelsUrl || `https://www.instagram.com/${username}/reels/`);

  if (handleEl) handleEl.textContent = `@${username}`;
  if (badgeEl) badgeEl.textContent = `${reel.outlierMultiplier || 8.5}x Viral`;
  if (viewsEl) viewsEl.textContent = `👁️ ${Number(reel.views || 45000).toLocaleString('pt-BR')} visualizações`;
  if (durEl) durEl.textContent = `0:${String(reel.durationSec || 38).padStart(2, '0')}`;
  if (tagEl) tagEl.textContent = reel.onScreenText || reel.hookType || 'MANCHETE DO VÍDEO';
  if (hookEl) hookEl.textContent = `"${reel.hookText || 'Olha na tela o que está acontecendo agora...'}"`;

  if (urlDisplay) {
    urlDisplay.href = directPostUrl;
    urlDisplay.textContent = directPostUrl;
  }

  if (centerPlayLink) {
    centerPlayLink.href = directPostUrl;
  }

  if (extLink) {
    extLink.href = directPostUrl;
    extLink.textContent = hasSpecificSc
      ? `▶️ Assistir no Instagram (/reel/${reel.shortcode}/) ↗`
      : `▶️ Assistir Reels de @${username} ↗`;
  }

  if (iframe) {
    iframe.src = hasSpecificSc ? `https://www.instagram.com/p/${reel.shortcode}/embed/` : '';
    iframe.classList.add('hidden');
  }
  if (mockup) {
    mockup.style.display = '';
  }

  modal.classList.remove('hidden');
}

function closeMiniReelPlayer() {
  const modal = document.getElementById('miniPlayerModal');
  const iframe = document.getElementById('miniPlayerIframe');
  const mockup = document.getElementById('miniPlayerMockup');
  if (iframe) {
    iframe.src = '';
    iframe.classList.add('hidden');
  }
  if (mockup) mockup.style.display = '';
  modal?.classList.add('hidden');
}

document.getElementById('closeMiniPlayerBtn')?.addEventListener('click', closeMiniReelPlayer);
document.getElementById('miniPlayerModal')?.addEventListener('click', (e) => {
  if (e.target.id === 'miniPlayerModal') closeMiniReelPlayer();
});

document.getElementById('miniPlayerCopyUrlBtn')?.addEventListener('click', () => {
  const author = activePlayingReel?.username || 'referencia';
  const hasValidSc = Boolean(activePlayingReel?.linkVerified && activePlayingReel?.shortcode);
  const directPostUrl = hasValidSc
    ? `https://www.instagram.com/reel/${activePlayingReel.shortcode}/`
    : (activePlayingReel?.videoUrl || activePlayingReel?.reelsUrl || `https://www.instagram.com/${author}/reels/`);
  navigator.clipboard.writeText(directPostUrl);
  const btn = document.getElementById('miniPlayerCopyUrlBtn');
  if (btn) {
    btn.textContent = '✅ Copiado!';
    setTimeout(() => { btn.textContent = '📋 Copiar'; }, 2000);
  }
});

document.getElementById('miniPlayerToggleEmbedBtn')?.addEventListener('click', () => {
  const iframe = document.getElementById('miniPlayerIframe');
  const mockup = document.getElementById('miniPlayerMockup');
  const btn = document.getElementById('miniPlayerToggleEmbedBtn');
  if (iframe && mockup) {
    const isShowingIframe = !iframe.classList.contains('hidden');
    if (isShowingIframe) {
      iframe.classList.add('hidden');
      mockup.style.display = '';
      if (btn) btn.textContent = '🔁 Embed';
    } else {
      iframe.classList.remove('hidden');
      mockup.style.display = 'none';
      if (btn) btn.textContent = '🔁 Player';
    }
  }
});

document.getElementById('miniPlayerCopyHookBtn')?.addEventListener('click', () => {
  if (activePlayingReel?.hookText) {
    navigator.clipboard.writeText(activePlayingReel.hookText);
    const btn = document.getElementById('miniPlayerCopyHookBtn');
    if (btn) {
      btn.textContent = '✅ Copiado!';
      setTimeout(() => { btn.textContent = '📋 Gancho'; }, 2000);
    }
  }
});

function renderLiveProfilesTable() {
  const tbody = document.getElementById('profilesLiveTbody');
  if (!tbody || !currentState) return;

  const user = currentState.userProfile;
  const competitors = currentState.competitors || [];
  const all = [
    ...(user ? [{ ...user, isUser: true }] : []),
    ...competitors.map((c) => ({ ...c, isUser: false }))
  ];

  if (all.length === 0) {
    tbody.innerHTML = `<tr><td colspan="6" style="text-align:center; color:var(--text-muted); padding:1rem;">Nenhum perfil ativo.</td></tr>`;
    return;
  }

  tbody.innerHTML = all.map((prof) => {
    const topOutlier = prof.outliers?.[0] || prof.postsWithRelativeScore?.[0] || {};
    const mult = topOutlier.outlierMultiplier ? `${topOutlier.outlierMultiplier}x` : '1.0x';
    const hook = topOutlier.hookType || 'Abertura Direta';

    // Garante fidelidade absoluta: só cria /reel/ se houver shortcode 100% verificado pela origem
    const hasSpecificReel = Boolean(topOutlier.linkVerified && topOutlier.shortcode);
    const targetUrl = hasSpecificReel
      ? `https://www.instagram.com/reel/${topOutlier.shortcode}/`
      : (topOutlier.reelsUrl || `https://www.instagram.com/${prof.username}/reels/`);
    const btnLabel = hasSpecificReel
      ? `🎬 Assistir Reel ↗`
      : `🎬 Reels de @${esc(prof.username)} ↗`;

    return `
      <tr style="${prof.isUser ? 'background:rgba(99,102,241,0.08); font-weight:700;' : ''}">
        <td>
          <div style="display:flex; align-items:center; gap:0.45rem;">
            <img src="${makeInlineAvatarSvg(prof.username)}" style="width:22px; height:22px; border-radius:50%;" />
            <a href="https://www.instagram.com/${esc(prof.username)}/" target="_blank" rel="noopener" style="color:var(--text-primary); text-decoration:none; font-weight:600;" title="Abrir perfil @${esc(prof.username)} no Instagram">
              @${esc(prof.username)} ${prof.isUser ? '(Você)' : ''}
            </a>
          </div>
        </td>
        <td>${Number(prof.baselineMedianViews || 0).toLocaleString('pt-BR')}</td>
        <td><strong style="color:var(--emerald);">${esc(mult)}</strong></td>
        <td>${esc(prof.postingFrequencyPerWeek || 3)}/sem</td>
        <td>${esc(hook)}</td>
        <td>
          <a href="${esc(targetUrl)}" target="_blank" rel="noopener" class="btn-action-outline" style="text-decoration:none; padding:0.35rem 0.65rem; font-size:0.74rem; font-weight:700;" title="Abrir conteúdo de @${esc(prof.username)} no Instagram">
            ${btnLabel}
          </a>
        </td>
      </tr>
    `;
  }).join('');
}

function renderScriptsTab() {
  const container = document.getElementById('scriptsContainer');
  const pack = currentState?.contentPack;
  if (!container || !pack) return;

  const ideas = pack.prioritizedIdeas || [];
  if (ideas.length === 0) {
    container.innerHTML = `<p style="color:var(--text-muted); padding:1.25rem;">Nenhum roteiro gerado ainda. Clique em "Atualizar Radar" acima.</p>`;
    return;
  }

  container.innerHTML = ideas.map((idea, idx) => {
    const refSnap = idea.referenceVideoSnapshot || currentState.extremeRelevanceVideo || {};
    return `
      <div class="script-bento-card">
        <div class="script-card-header">
          <div>
            <h3>🎬 Roteiro #${idx + 1}: ${esc(idea.title)}</h3>
            <p class="script-ref-sub">Modelado do outlier de @${esc(refSnap.username || 'referencia')} (${esc(refSnap.outlierMultiplier || 8.5)}x a média do nicho)</p>
          </div>
          <button type="button" class="btn-action-outline" data-view-ref-idx="${idx}">
            ▶️ Ver Reel de Referência
          </button>
        </div>

        <div class="hooks-selector-strip">
          <label>Variação de Gancho Inicial (0s a 3s):</label>
          <div class="hooks-chips">
            ${(idea.alternativeHooks || []).map((h, hIdx) => `
              <button type="button" class="hook-choice-btn ${hIdx === 0 ? 'selected' : ''}" data-hook-script-idx="${idx}" data-hook-text="${esc(h.text)}">
                ${esc(h.type.split('(')[0].trim())}
              </button>
            `).join('')}
          </div>
        </div>

        <div class="script-text-body" id="scriptSpokenText-${idx}" data-base-script="${esc(idea.reelScript.spokenText)}">${esc(idea.reelScript.spokenText)}</div>

        <div class="script-footer-actions">
          <!-- BOTÃO DE DESTAQUE: WHATSAPP DA EQUIPE -->
          <button type="button" class="btn-wa-export" data-whatsapp-script-idx="${idx}" data-title="${esc(idea.title)}">
            📲 Copiar p/ WhatsApp da Equipe
          </button>
          <button type="button" class="btn-action-outline" data-copy-script-idx="${idx}">
            📋 Copiar Texto
          </button>
          <button type="button" class="btn-action-outline" data-open-tp-idx="${idx}">
            🎙️ Teleprompter
          </button>
          <a href="${esc(refSnap.videoUrl)}" target="_blank" rel="noopener" class="btn-action-outline">
            🎬 Instagram ↗
          </a>
        </div>
      </div>
    `;
  }).join('');

  // Botões de trocar gancho
  container.querySelectorAll('button[data-hook-script-idx]').forEach((btn) => {
    btn.addEventListener('click', () => {
      const idx = btn.getAttribute('data-hook-script-idx');
      const hookText = btn.getAttribute('data-hook-text').replace(/^"+|"+$/g, '');
      container.querySelectorAll(`button[data-hook-script-idx="${idx}"]`).forEach((b) => {
        b.classList.remove('selected');
      });
      btn.classList.add('selected');

      const scriptEl = document.getElementById(`scriptSpokenText-${idx}`);
      if (scriptEl) {
        const base = scriptEl.getAttribute('data-base-script') || scriptEl.textContent;
        const lines = base.split('\n');
        lines[0] = `[00s-03s] ${hookText}`;
        scriptEl.textContent = lines.join('\n');
      }
    });
  });

  // Botão WhatsApp da Equipe
  container.querySelectorAll('button[data-whatsapp-script-idx]').forEach((btn) => {
    btn.addEventListener('click', () => {
      const idx = btn.getAttribute('data-whatsapp-script-idx');
      const title = btn.getAttribute('data-title') || 'Roteiro de Gravação';
      const scriptEl = document.getElementById(`scriptSpokenText-${idx}`);
      if (!scriptEl) return;
      const body = scriptEl.textContent;
      const lines = body.split('\n').filter(Boolean);
      const hook = lines[0] || '';
      const content = lines.slice(1).join('\n');

      const waText = 
`🎬 *ROTEIRO DE GRAVAÇÃO (ASCOM FRED)*
📌 *Título:* ${title}
⚡ *Gancho Inicial (0-3s):*
${hook}

📝 *Desenvolvimento / Fala:*
${content}

💡 *Instruções da Equipe:*
• Gravar na vertical (9:16) com olhar direto na lente.
• Primeiro segundo com movimento corporal ou objeto em cena.
• Legendas dinâmicas no centro da tela.`;

      navigator.clipboard.writeText(waText);
      btn.textContent = '✅ Copiado p/ WhatsApp!';
      showToast('📲 Roteiro formatado copiado para colar no WhatsApp da Equipe!');
      setTimeout(() => { btn.textContent = '📲 Copiar p/ WhatsApp da Equipe'; }, 2200);
    });
  });

  // Botão abrir na mini janela a partir do roteiro
  container.querySelectorAll('button[data-view-ref-idx]').forEach((btn) => {
    btn.addEventListener('click', () => {
      const idx = Number(btn.getAttribute('data-view-ref-idx'));
      const ref = ideas[idx]?.referenceVideoSnapshot || currentState.extremeRelevanceVideo;
      if (ref) openMiniReelPlayer(ref);
    });
  });

  // Botão copiar roteiro simples
  container.querySelectorAll('button[data-copy-script-idx]').forEach((btn) => {
    btn.addEventListener('click', () => {
      const idx = btn.getAttribute('data-copy-script-idx');
      const scriptEl = document.getElementById(`scriptSpokenText-${idx}`);
      if (scriptEl) {
        navigator.clipboard.writeText(scriptEl.textContent);
        btn.textContent = '✅ Copiado!';
        showToast('📋 Roteiro copiado para a área de transferência!');
        setTimeout(() => { btn.textContent = '📋 Copiar Texto'; }, 2000);
      }
    });
  });

  // Botão Teleprompter
  container.querySelectorAll('button[data-open-tp-idx]').forEach((btn) => {
    btn.addEventListener('click', () => {
      const idx = btn.getAttribute('data-open-tp-idx');
      const scriptEl = document.getElementById(`scriptSpokenText-${idx}`);
      const modal = document.getElementById('teleprompterModal');
      const content = document.getElementById('teleprompterContent');
      if (scriptEl && modal && content) {
        content.textContent = scriptEl.textContent;
        modal.classList.remove('hidden');
      }
    });
  });
}

function formatChatMarkdown(raw) {
  let safe = esc(raw);
  safe = safe.replace(/^### (.*)$/gm, '<strong style="display:block; font-size:0.95rem; color:var(--primary); margin:0.35rem 0;">$1</strong>');
  safe = safe.replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>');
  safe = safe.replace(/`([^`]+)`/g, '<code style="background:rgba(2,132,199,0.18); padding:0.1rem 0.35rem; border-radius:4px;">$1</code>');
  safe = safe.replace(/(https?:\/\/[^\s<)]+)/g, '<a href="$1" target="_blank" rel="noopener" style="color:var(--primary); text-decoration:underline;">$1</a>');
  return safe;
}

function renderChatMessages() {
  const box = document.getElementById('chatMessages');
  if (!box || !currentState) return;

  const history = currentState.chatHistory || [];
  box.innerHTML = history.map((m) => `
    <div class="chat-msg ${m.role === 'user' ? 'user' : 'assistant'}">
      ${formatChatMarkdown(m.text)}
    </div>
  `).join('');

  box.scrollTop = box.scrollHeight;
}

async function sendChatMessage(msgText) {
  const input = document.getElementById('chatInput');
  if (input) input.value = '';

  currentState.chatHistory = [
    ...(currentState.chatHistory || []),
    { role: 'user', text: msgText },
    { role: 'assistant', text: '⏳ Processando resposta...' }
  ];
  renderChatMessages();

  try {
    const res = await fetch('/api/chat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', ...TEAM_HEADERS },
      body: JSON.stringify({ message: msgText })
    });
    const data = await res.json();
    if (data.chatHistory) {
      currentState.chatHistory = data.chatHistory;
      renderChatMessages();
    }
  } catch (err) {
    console.error('Erro no chat:', err);
  }
}

document.getElementById('chatForm')?.addEventListener('submit', (e) => {
  e.preventDefault();
  const input = document.getElementById('chatInput');
  const msg = input.value.trim();
  if (!msg) return;
  sendChatMessage(msg);
});

document.querySelectorAll('.prompt-chip').forEach((chip) => {
  chip.addEventListener('click', () => {
    const prompt = chip.getAttribute('data-prompt');
    if (prompt) sendChatMessage(prompt);
  });
});

document.getElementById('clearChatBtn')?.addEventListener('click', async () => {
  const res = await fetch('/api/clear-chat', { method: 'POST', headers: { ...TEAM_HEADERS } });
  const data = await res.json();
  if (data.chatHistory) {
    currentState.chatHistory = data.chatHistory;
    renderChatMessages();
  }
});

// Navegação das 3 abas principais
document.querySelectorAll('.nav-tab').forEach((tabBtn) => {
  tabBtn.addEventListener('click', () => {
    document.querySelectorAll('.nav-tab').forEach((t) => t.classList.remove('active'));
    document.querySelectorAll('.tab-content').forEach((c) => c.classList.remove('active'));
    tabBtn.classList.add('active');
    const targetId = tabBtn.getAttribute('data-tab');
    document.getElementById(targetId)?.classList.add('active');
  });
});

// Ações do Pipeline
document.getElementById('addCompetitorBtn')?.addEventListener('click', addHandleFromInput);
document.getElementById('addCompetitorInput')?.addEventListener('keydown', (e) => {
  if (e.key === 'Enter') {
    e.preventDefault();
    addHandleFromInput();
  }
});

document.getElementById('clearCompetitorsBtn')?.addEventListener('click', () => {
  listedCompetitors = [];
  renderListedChips();
});

document.getElementById('loadNicheSuggestionsBtn')?.addEventListener('click', () => {
  const nicheId = document.getElementById('nicheSelect')?.value;
  const selected = currentState?.niches?.find((n) => n.id === nicheId);
  if (selected) {
    for (const h of selected.referenceHandles) {
      const cl = cleanHandle(h);
      if (cl && !listedCompetitors.includes(cl)) listedCompetitors.push(cl);
    }
    renderListedChips();
  }
});

document.getElementById('quickAnalyzeForm')?.addEventListener('submit', async (e) => {
  e.preventDefault();
  addHandleFromInput();

  const btn = document.getElementById('analyzeBtn');
  const oldText = btn.textContent;
  btn.textContent = '⏳ Sincronizando dados e gerando roteiros...';
  btn.disabled = true;

  try {
    const userHandle = document.getElementById('userHandleInput').value;
    const nicheId = document.getElementById('nicheSelect').value;

    const res = await fetch('/api/quick-analyze', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', ...TEAM_HEADERS },
      body: JSON.stringify({
        userHandle,
        nicheId,
        competitorHandles: listedCompetitors
      })
    });
    currentState = await res.json();
    listedCompetitors = (currentState.competitors || []).map((c) => c.username);
    renderAll();
  } finally {
    btn.textContent = oldText;
    btn.disabled = false;
  }
});

// Adicionar Reel Real customizado
document.getElementById('addCustomReelForm')?.addEventListener('submit', async (e) => {
  e.preventDefault();
  const input = document.getElementById('customReelUrlInput');
  const url = input?.value?.trim();
  if (!url) return;

  const submitBtn = e.target.querySelector('button[type="submit"]');
  const oldText = submitBtn ? submitBtn.textContent : '';
  if (submitBtn) {
    submitBtn.textContent = '⏳ Adicionando...';
    submitBtn.disabled = true;
  }

  try {
    const res = await fetch('/api/add-custom-reel', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', ...TEAM_HEADERS },
      body: JSON.stringify({ url })
    });
    const result = await res.json();
    if (result.ok && result.dashboard) {
      currentState = result.dashboard;
      input.value = '';
      renderAll();
      if (result.addedReel) {
        openMiniReelPlayer(result.addedReel);
      }
    }
  } catch (err) {
    console.error('Erro ao adicionar reel real:', err);
  } finally {
    if (submitBtn) {
      submitBtn.textContent = oldText;
      submitBtn.disabled = false;
    }
  }
});

document.getElementById('liveSyncBtn')?.addEventListener('click', triggerLiveSync);

// Auditoria Visual de Vídeos (Pré-Postagem)
document.getElementById('videoAuditForm')?.addEventListener('submit', async (e) => {
  e.preventDefault();
  const urlInput = document.getElementById('auditVideoUrlInput');
  const objSelect = document.getElementById('auditObjectiveSelect');
  const submitBtn = document.getElementById('btnRunAudit');
  const resultsContainer = document.getElementById('auditResultContainer');
  if (!urlInput || !resultsContainer) return;

  const oldHtml = submitBtn ? submitBtn.innerHTML : '';
  if (submitBtn) {
    submitBtn.innerHTML = '<span>⏳ IA Assistindo e Auditando Vídeo...</span>';
    submitBtn.disabled = true;
  }

  try {
    const res = await fetch('/api/audit-video', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        url: urlInput.value,
        objective: objSelect ? objSelect.value : 'viral'
      })
    });
    const data = await res.json();
    if (data.ok && data.audit) {
      const a = data.audit;
      resultsContainer.innerHTML = `
        <div class="audit-score-banner">
          <div class="score-badge-large">
            <span class="score-number">${a.overallScore}%</span>
            <div>
              <span class="badge-pill" style="margin-bottom:0.2rem;">Crivo Técnico Ascom</span>
              <div class="score-verdict-text" style="color:${a.statusColor};">${esc(a.verdict)}</div>
            </div>
          </div>
          <div style="font-size:0.78rem; color:var(--text-muted); max-width:380px;">
            Avaliação multimodal de enquadramento, primeiro segundo e retenção realizada pela IA de visão da equipe.
          </div>
        </div>

        <div class="criteria-grid">
          ${a.criteria.map((c) => `
            <div class="criterion-card">
              <div class="crit-header">
                <span class="crit-name">${esc(c.name)}</span>
                <span class="crit-score">${esc(c.score)}%</span>
              </div>
              <p class="crit-desc">${esc(c.detail)}</p>
            </div>
          `).join('')}
        </div>

        <div class="checklist-box">
          <h4>📋 Checklist de Aprovação da Ascom</h4>
          <div class="checklist-items">
            ${a.teamChecklist.map((item) => `
              <div class="checklist-item">
                <span class="check-tick">✓</span>
                <span>${esc(item.item)}</span>
              </div>
            `).join('')}
          </div>
        </div>
      `;
      resultsContainer.classList.remove('hidden');
      resultsContainer.scrollIntoView({ behavior: 'smooth' });
      showToast('✅ Auditoria do vídeo concluída com sucesso!');
    }
  } catch (err) {
    console.error('Erro na auditoria de vídeo:', err);
    showToast('❌ Erro ao auditar o vídeo.');
  } finally {
    if (submitBtn) {
      submitBtn.innerHTML = oldHtml;
      submitBtn.disabled = false;
    }
  }
});

// Alternar Tema Escuro / Claro
document.getElementById('themeToggleBtn')?.addEventListener('click', () => {
  const html = document.documentElement;
  const next = html.getAttribute('data-theme') === 'light' ? 'dark' : 'light';
  html.setAttribute('data-theme', next);
});

// Compartilhamento
async function loadShareLink() {
  try {
    const res = await fetch('/api/share');
    const info = await res.json();
    const shareUrl = info.publicUrl || info.lanUrl || window.location.origin;
    const input = document.getElementById('publicShareInput');
    const waBtn = document.getElementById('whatsappShareBtn');
    if (input) input.value = shareUrl;
    if (waBtn) {
      const msg = encodeURIComponent(`🚀 Acesse o RP RESOLVE (Monitoramento Ao Vivo, Reels em Alta & IA): ${shareUrl}`);
      waBtn.href = `https://wa.me/?text=${msg}`;
    }
    if (!info.publicUrl) setTimeout(loadShareLink, 3000);
  } catch {}
}

document.getElementById('copyShareLinkBtn')?.addEventListener('click', () => {
  const input = document.getElementById('publicShareInput');
  const btn = document.getElementById('copyShareLinkBtn');
  if (input && btn) {
    navigator.clipboard.writeText(input.value);
    btn.textContent = '✅ Copiado!';
    setTimeout(() => { btn.textContent = '📋 Copiar'; }, 2000);
  }
});

// Teleprompter Controls
let tpTimer = null;
let tpFont = 1.55;

document.getElementById('tpCloseBtn')?.addEventListener('click', () => {
  if (tpTimer) { clearInterval(tpTimer); tpTimer = null; }
  document.getElementById('teleprompterModal')?.classList.add('hidden');
});

document.getElementById('tpFontPlusBtn')?.addEventListener('click', () => {
  tpFont = Math.min(2.5, Number((tpFont + 0.15).toFixed(2)));
  const el = document.getElementById('teleprompterContent');
  if (el) el.style.fontSize = `${tpFont}rem`;
});

document.getElementById('tpFontMinusBtn')?.addEventListener('click', () => {
  tpFont = Math.max(1.0, Number((tpFont - 0.15).toFixed(2)));
  const el = document.getElementById('teleprompterContent');
  if (el) el.style.fontSize = `${tpFont}rem`;
});

document.getElementById('tpAutoScrollBtn')?.addEventListener('click', (e) => {
  const btn = e.currentTarget;
  const el = document.getElementById('teleprompterContent');
  if (!el) return;
  if (tpTimer) {
    clearInterval(tpTimer);
    tpTimer = null;
    btn.textContent = '▶️ Rolagem';
  } else {
    btn.textContent = '⏸️ Pausar';
    tpTimer = setInterval(() => { el.scrollTop += 1; }, 45);
  }
});

// Inicia aplicação
fetchState();
loadShareLink();
// Sincronização em tempo real periódica (a cada 45 segundos)
setInterval(triggerLiveSync, 45000);
