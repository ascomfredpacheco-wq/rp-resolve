import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import { loadDatabase, saveDatabase } from '../src/storage.js';
import { collectProfileData, getNicheCatalog, normalizeHandle } from '../src/dataCollector.js';

test('normalizeHandle limpa @, espaços e URLs do Instagram', () => {
  assert.equal(normalizeHandle(' @MeuPerfil.Oficial '), 'meuperfil.oficial');
  assert.equal(normalizeHandle('https://www.instagram.com/criador_top/'), 'criador_top');
});

test('storage carrega estado padrão e persiste alterações em disco', () => {
  const tempFile = path.join(os.tmpdir(), `instaviral-test-${Date.now()}.json`);
  const initial = loadDatabase(tempFile);
  assert.equal(typeof initial.userProfile, 'object');
  assert.equal(Array.isArray(initial.competitors), true);

  initial.userProfile = { username: 'meu_perfil_teste', niche: 'marketing' };
  saveDatabase(tempFile, initial);

  const reloaded = loadDatabase(tempFile);
  assert.equal(reloaded.userProfile.username, 'meu_perfil_teste');
  fs.unlinkSync(tempFile);
});

test('getNicheCatalog retorna os nichos incluindo Direito/Advocacia e Política com assuntos em alta e links reais', () => {
  const catalog = getNicheCatalog();
  assert.equal(catalog.length >= 11, true);
  const marketing = catalog.find((n) => n.id === 'marketing');
  const direito = catalog.find((n) => n.id === 'direito');
  const politica = catalog.find((n) => n.id === 'politica');
  assert.ok(marketing);
  assert.ok(direito);
  assert.ok(politica);
  assert.equal(Array.isArray(direito.trendingTopics), true);
  assert.equal(Array.isArray(politica.trendingTopics), true);
});

test('collectProfileData retorna dados com origem identificável e links válidos do Instagram', async () => {
  const profile = await collectProfileData('@fitness_ref_br', { nicheHint: 'fitness', skipNetwork: true });
  assert.equal(profile.username, 'fitness_ref_br');
  assert.ok(profile.sourceType);
  assert.ok(profile.sourceNotice);
  assert.equal(Array.isArray(profile.posts), true);
  assert.equal(profile.posts.length >= 6, true);
  for (const post of profile.posts) {
    assert.match(post.permalink, /^https:\/\/www\.instagram\.com\//);
    assert.equal(typeof post.views, 'number');
    assert.equal(typeof post.likes, 'number');
    assert.equal(typeof post.comments, 'number');
  }
});
