import test from 'node:test';
import assert from 'node:assert/strict';
import {
  analyzeProfile,
  discoverViralOutliers,
  reverseEngineerReel,
  analyzeNichePatterns,
  compareWithUserProfile,
  buildCrossProfileDeepAnalysis
} from '../src/analyticsEngine.js';
import { collectProfileData } from '../src/dataCollector.js';

test('analyzeProfile calcula mediana, outlierMultiplier e protege contra zero posts', async () => {
  const emptyAnalysis = analyzeProfile({ username: 'vazio', posts: [] });
  assert.equal(emptyAnalysis.baselineMedianViews, 0);
  assert.equal(emptyAnalysis.outliers.length, 0);

  const profile = await collectProfileData('@marketing_pro', { nicheHint: 'marketing', skipNetwork: true });
  const analysis = analyzeProfile(profile);
  assert.equal(analysis.username, 'marketing_pro');
  assert.ok(analysis.baselineMedianViews > 0);
  assert.ok(analysis.outliers.length >= 1);
  assert.ok(analysis.outliers[0].outlierMultiplier > 2);
  assert.ok(Array.isArray(analysis.diagnostic.strengths));
  assert.ok(Array.isArray(analysis.diagnostic.opportunities));
});

test('discoverViralOutliers prioriza desempenho relativo (50k em perfil de 3k > 200k em perfil de 1M)', () => {
  const smallCreator = {
    username: 'criador_pequeno',
    niche: 'marketing',
    followers: 4000,
    posts: [
      { id: 's1', format: 'Reel', views: 50000, likes: 4200, comments: 310, daysAgo: 3, hookText: 'Erro número 1', permalink: 'https://www.instagram.com/criador_pequeno/' },
      { id: 's2', format: 'Reel', views: 3000, likes: 120, comments: 10, daysAgo: 7, hookText: 'Post normal 1', permalink: 'https://www.instagram.com/criador_pequeno/' },
      { id: 's3', format: 'Reel', views: 3000, likes: 110, comments: 9, daysAgo: 10, hookText: 'Post normal 2', permalink: 'https://www.instagram.com/criador_pequeno/' }
    ]
  };

  const hugeCreator = {
    username: 'criador_gigante',
    niche: 'marketing',
    followers: 2000000,
    posts: [
      { id: 'h1', format: 'Reel', views: 200000, likes: 8000, comments: 400, daysAgo: 3, hookText: 'Post abaixo da média', permalink: 'https://www.instagram.com/criador_gigante/' },
      { id: 'h2', format: 'Reel', views: 1000000, likes: 50000, comments: 2000, daysAgo: 6, hookText: 'Post normal 1', permalink: 'https://www.instagram.com/criador_gigante/' },
      { id: 'h3', format: 'Reel', views: 1000000, likes: 48000, comments: 1900, daysAgo: 9, hookText: 'Post normal 2', permalink: 'https://www.instagram.com/criador_gigante/' }
    ]
  };

  const ranking = discoverViralOutliers([smallCreator, hugeCreator]);
  assert.ok(ranking.length >= 1);
  assert.equal(ranking[0].postId, 's1');
  assert.ok(ranking[0].outlierMultiplier > 15);
  assert.ok(ranking[0].whyStudy.includes('acima da mediana'));
});

test('reverseEngineerReel decompõe em 5 blocos e separa FATO OBSERVADO, INFERÊNCIA e HIPÓTESE', async () => {
  const profile = await collectProfileData('@fitness_expert', { nicheHint: 'fitness', skipNetwork: true });
  const analyzed = analyzeProfile(profile);
  const topReel = analyzed.outliers[0];
  const deconstruction = reverseEngineerReel(topReel, analyzed.baselineMedianViews);

  assert.ok(deconstruction.hook);
  assert.ok(deconstruction.development);
  assert.ok(deconstruction.retentionPotential);
  assert.ok(deconstruction.packaging);
  assert.ok(deconstruction.conclusion);
  assert.equal(deconstruction.hook.observedFact.evidenceType, 'FATO OBSERVADO');
  assert.equal(deconstruction.hook.hypothesis.evidenceType, 'HIPÓTESE');
  assert.equal(deconstruction.retentionPotential.inference.evidenceType, 'INFERÊNCIA');
  assert.ok(deconstruction.epistemicDisclaimer.includes('não prova causalidade isolada'));
});

test('analyzeNichePatterns e compareWithUserProfile geram padrões cruzados e lacunas do usuário', async () => {
  const userProf = await collectProfileData('@meu_perfil_atual', { nicheHint: 'marketing', isUserOwnProfile: true, skipNetwork: true });
  const comp1 = await collectProfileData('@ref_mkt_1', { nicheHint: 'marketing', skipNetwork: true });
  const comp2 = await collectProfileData('@ref_mkt_2', { nicheHint: 'marketing', skipNetwork: true });

  const nicheReport = analyzeNichePatterns('marketing', [comp1, comp2]);
  assert.ok(nicheReport.confirmedPatterns.length >= 2);
  assert.ok(nicheReport.trendingTopics.length >= 1);

  const comparison = compareWithUserProfile(userProf, [comp1, comp2]);
  assert.equal(comparison.userSummary.username, 'meu_perfil_atual');
  assert.ok(comparison.gapsAndOpportunities.length >= 2);
});

test('buildCrossProfileDeepAnalysis salva links dos vídeos, avalia hooks e temas polêmicos, cruza dados e destaca o vídeo de EXTREMA RELEVÂNCIA', async () => {
  const userProf = analyzeProfile(await collectProfileData('@fredpachecorj', { nicheHint: 'politica', isUserOwnProfile: true, skipNetwork: true }));
  const comp1 = analyzeProfile(await collectProfileData('@nikolasferreiradm', { nicheHint: 'politica', skipNetwork: true }));
  const comp2 = analyzeProfile(await collectProfileData('@india_armelau', { nicheHint: 'politica', skipNetwork: true }));

  const deepCross = buildCrossProfileDeepAnalysis(userProf, [comp1, comp2], 'politica');

  assert.ok(Array.isArray(deepCross.savedVideos));
  assert.ok(deepCross.savedVideos.length >= 4);
  assert.ok(deepCross.savedVideos[0].videoUrl.startsWith('https://www.instagram.com/'));
  assert.ok(deepCross.savedVideos[0].polemicTheme.length > 10);

  assert.ok(deepCross.extremeRelevanceVideo);
  assert.equal(deepCross.extremeRelevanceVideo.relevanceBadge, 'EXTREMA RELEVÂNCIA PARA VIRALIZAR');
  assert.ok(deepCross.extremeRelevanceVideo.videoUrl.startsWith('https://www.instagram.com/'));
  assert.ok(deepCross.extremeRelevanceVideo.hookText.length > 10);
  assert.ok(deepCross.extremeRelevanceVideo.polemicTheme.length > 10);
  assert.ok(deepCross.extremeRelevanceVideo.crossDataJustification.length > 20);
  assert.ok(Array.isArray(deepCross.extremeRelevanceVideo.howToModelSteps));

  assert.ok(Array.isArray(deepCross.winningHooksEvaluation) && deepCross.winningHooksEvaluation.length >= 2);
  assert.ok(Array.isArray(deepCross.polemicThemesEvaluation) && deepCross.polemicThemesEvaluation.length >= 2);
  assert.ok(Array.isArray(deepCross.crossDataPatterns) && deepCross.crossDataPatterns.length >= 3);
});
