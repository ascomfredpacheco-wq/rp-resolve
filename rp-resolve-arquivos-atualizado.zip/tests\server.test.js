import test from 'node:test';
import assert from 'node:assert/strict';
import os from 'node:os';
import path from 'node:path';
import fs from 'node:fs';
import { createAppServer } from '../src/server.js';

test('API Server processa fluxo completo: analisar meu perfil + concorrentes, comparar, gerar roteiros, corrigir classificação e registrar resultado', async () => {
  const tempDb = path.join(os.tmpdir(), `instaviral-api-${Date.now()}.json`);
  const server = createAppServer({ dbPath: tempDb, skipNetwork: true });

  await new Promise((resolve) => server.listen(0, '127.0.0.1', resolve));
  const { port } = server.address();
  const baseUrl = `http://127.0.0.1:${port}`;

  try {
    // 1. Carregar estado inicial e catálogo de nichos
    const stateRes = await fetch(`${baseUrl}/api/state`);
    assert.equal(stateRes.status, 200);
    const stateData = await stateRes.json();
    assert.ok(Array.isArray(stateData.niches));
    assert.ok(stateData.niches.length >= 9);

    // 2. Execução 1-clique: analisar meu perfil + concorrentes automaticamente
    const analyzeRes = await fetch(`${baseUrl}/api/quick-analyze`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        userHandle: '@meu_negocio_digital',
        competitorHandles: ['@leandrokalil', '@hyeser'],
        nicheId: 'marketing',
        goal: 'Viralizar Reels e vender mentoria no Direct'
      })
    });
    assert.equal(analyzeRes.status, 200);
    const fullDashboard = await analyzeRes.json();

    assert.equal(fullDashboard.userProfile.username, 'meu_negocio_digital');
    assert.equal(fullDashboard.competitors.length, 2);
    assert.ok(fullDashboard.viralOutliers.length >= 2);
    assert.ok(fullDashboard.comparison.gapsAndOpportunities.length >= 2);
    assert.ok(fullDashboard.contentPack.prioritizedIdeas.length >= 3);
    assert.ok(fullDashboard.reverseEngineeredTopReel.hook.observedFact);

    // 3. Permitir correção manual de classificação pelo usuário
    const targetPostId = fullDashboard.viralOutliers[0].postId;
    const reclassRes = await fetch(`${baseUrl}/api/reclassify`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        postId: targetPostId,
        newFormat: 'Reel',
        newTheme: 'Tema Corrigido Manualmente pelo Usuário'
      })
    });
    assert.equal(reclassRes.status, 200);
    const reclassData = await reclassRes.json();
    assert.equal(reclassData.ok, true);

    // 4. Registrar resultado real de publicação do usuário para aprendizado
    const resultRes = await fetch(`${baseUrl}/api/record-result`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        title: 'Reel Erro Invisível #1',
        format: 'Reel',
        hookType: 'Quebra de Expectativa + Erro Comum',
        views: 42000,
        likes: 3900,
        comments: 280
      })
    });
    assert.equal(resultRes.status, 200);
    const resultData = await resultRes.json();
    assert.equal(resultData.publishedResults.length, 1);

    // 5. Chat Estrategista IA
    const chatRes = await fetch(`${baseUrl}/api/chat`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        message: 'Qual o melhor roteiro para eu gravar hoje?'
      })
    });
    assert.equal(chatRes.status, 200);
    const chatData = await chatRes.json();
    assert.ok(chatData.reply.text.length > 30);

    // 6. Acompanhamento em tempo real das redes (/api/live-sync)
    const syncRes = await fetch(`${baseUrl}/api/live-sync`, { method: 'POST' });
    assert.equal(syncRes.status, 200);
    const syncData = await syncRes.json();
    assert.equal(syncData.ok, true);
    assert.ok(syncData.lastLiveSync);
  } finally {
    await new Promise((resolve) => server.close(resolve));
    if (fs.existsSync(tempDb)) fs.unlinkSync(tempDb);
  }
});

test('API Server isola dados salvos (@ do usuário e @ listados) por IP para que outro IP não veja dados alheios', async () => {
  const tempDb = path.join(os.tmpdir(), `instaviral-ip-isolation-${Date.now()}.json`);
  const server = createAppServer({ dbPath: tempDb, skipNetwork: true });

  await new Promise((resolve) => server.listen(0, '127.0.0.1', resolve));
  const { port } = server.address();
  const baseUrl = `http://127.0.0.1:${port}`;

  try {
    // IP 1 salva seus @
    const resAnalyzeIp1 = await fetch(`${baseUrl}/api/quick-analyze`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'CF-Connecting-IP': '177.10.20.30'
      },
      body: JSON.stringify({
        userHandle: '@perfil_exclusivo_ip1',
        competitorHandles: ['@concorrente_ip1_a', '@concorrente_ip1_b'],
        nicheId: 'direito'
      })
    });
    assert.equal(resAnalyzeIp1.status, 200);

    // IP 1 recarrega /api/state e vê seus próprios @
    const resStateIp1 = await fetch(`${baseUrl}/api/state`, {
      headers: { 'CF-Connecting-IP': '177.10.20.30' }
    });
    const stateIp1 = await resStateIp1.json();
    assert.equal(stateIp1.userProfile?.username, 'perfil_exclusivo_ip1');
    assert.deepEqual(
      stateIp1.competitors.map((c) => c.username),
      ['concorrente_ip1_a', 'concorrente_ip1_b']
    );

    // IP 2 entra no link pela primeira vez: NÃO pode ver os @ do IP 1!
    const resStateIp2 = await fetch(`${baseUrl}/api/state`, {
      headers: { 'CF-Connecting-IP': '200.55.66.77' }
    });
    const stateIp2 = await resStateIp2.json();
    assert.equal(stateIp2.userProfile, null);
    assert.deepEqual(stateIp2.competitors, []);

    // IP 2 faz sua própria análise com outros @
    await fetch(`${baseUrl}/api/quick-analyze`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'CF-Connecting-IP': '200.55.66.77'
      },
      body: JSON.stringify({
        userHandle: '@perfil_ip2',
        competitorHandles: ['@concorrente_ip2'],
        nicheId: 'politica'
      })
    });

    // Teste de inserção direta de reel real via /api/add-custom-reel
    const resAddCustom = await fetch(`${baseUrl}/api/add-custom-reel`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'CF-Connecting-IP': '177.10.20.30'
      },
      body: JSON.stringify({
        url: 'https://www.instagram.com/p/De1fO-zMoF-/'
      })
    });
    const addCustomJson = await resAddCustom.json();
    assert.equal(addCustomJson.ok, true);
    assert.equal(addCustomJson.addedReel.shortcode, 'De1fO-zMoF-');
    assert.ok(addCustomJson.addedReel.videoUrl.includes('De1fO-zMoF-'));
    assert.ok(addCustomJson.dashboard.viralOutliers.some((o) => o.shortcode === 'De1fO-zMoF-'));

    // IP 1 continua vendo apenas os seus dados originais, sem interferência do IP 2
    const resStateIp1After = await fetch(`${baseUrl}/api/state`, {
      headers: { 'CF-Connecting-IP': '177.10.20.30' }
    });
    const stateIp1After = await resStateIp1After.json();
    assert.equal(stateIp1After.userProfile?.username, 'perfil_exclusivo_ip1');
    assert.deepEqual(
      stateIp1After.competitors.map((c) => c.username),
      ['destaque', 'concorrente_ip1_a', 'concorrente_ip1_b']
    );
  } finally {
    await new Promise((resolve) => server.close(resolve));
    if (fs.existsSync(tempDb)) fs.unlinkSync(tempDb);
  }
});
